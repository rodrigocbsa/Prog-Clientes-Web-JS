
const main = document.querySelector( 'main' );

document.getElementById( 'pagina1' ).addEventListener(
    'click', carregarPagina1 );

document.getElementById( 'pagina2' ).addEventListener(
    'click', carregarPagina2 );

function carregarPagina1() {
    fetch( 'pagina1.html' )
        .then( function( response ) {
            if ( response.status >= 400 ) { // Erro
                throw new Error( 'Erro carregando página 1' );
            }
            return response.text();
        } )
        .then( function( texto ) {
            main.innerHTML = texto;
        } )
        .catch( function( erro ) {
            main.innerText = erro.message;
        } );
}

function carregarPagina2() {
    fetch( 'pagina2.html' )
        .then( function( response ) {
            if ( response.status >= 400 ) { // Erro
                throw new Error( 'Erro carregando página 2' );
            }
            return response.text();
        } )
        .then( function( texto ) {
            main.innerHTML = texto;
        } )
        .catch( function( erro ) {
            main.innerText = erro.message;
        } );
}