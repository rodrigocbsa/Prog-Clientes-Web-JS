
const main = document.querySelector( 'main' );

document.getElementById( 'pagina1' ).addEventListener(
    'click', function() {
        carregarPagina( 'pagina1.html', 'Erro ao carregar a página 1' );
    } );

document.getElementById( 'pagina2' ).addEventListener(
    'click', function() {
        carregarPagina( 'pagina2.html', 'Erro ao carregar a página 2' );
    } );

function carregarPagina( arquivo, mensagem ) {
    fetch( arquivo, {
        headers: {
            'Accept': 'text/html'
        }
    } )
        .then( function( response ) {
            if ( response.status >= 400 ) { // Erro
                throw new Error( mensagem );
            }
            return response.text();
        } )
        .then( function( texto ) {
            main.innerHTML = texto;
        } )
        .catch( function( erro ) {
            main.innerText = erro.message;
        } );
}