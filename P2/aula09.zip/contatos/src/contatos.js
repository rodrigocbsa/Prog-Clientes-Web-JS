fetch( 'http://localhost:8080/contatos' )
    .then( response => {
        if ( response.status >= 400 ) {
            throw new Error( 'Erro ao consultar os contatos.' );
        }
        return response.json();
    } )
    .then( contatos => desenharContatos( contatos ) )
    .catch( erro => alert( erro.message ) );

function desenharContatos( contatos ) {
    document.querySelector( 'ul' ).innerHTML =
        contatos.map( c =>
            `<li>${c.id} - ${c.nome} - ${c.telefone}</li>`
        ).join( '\n' );
}