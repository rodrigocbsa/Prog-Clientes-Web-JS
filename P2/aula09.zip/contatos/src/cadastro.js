document.getElementById( 'salvar' )
    .addEventListener( 'click', salvar );

function salvar( ev ) {
    ev.preventDefault();
    const contato = {
        nome: document.getElementById( 'nome' ).value,
        telefone: document.getElementById( 'telefone' ).value,
    };
    fetch( 'http://localhost:8080/contatos', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify( contato )
    } )
        .then( response => {
            if ( response.status >= 400 ) {
                throw new Error( 'Erro ao cadastrar o contato.' );
            }
            alert( 'Cadastrado.' );
            location.href = 'contatos.html'; // Redireciona
        } )
        .catch( erro => alert( erro.message ) );
}