<?php
header( 'Access-Control-Allow-Origin: *' );
header( 'Access-Control-Allow-Headers: *' );
header( 'Access-Control-Allow-Methods: GET,POST,PUT,DELETE' );

$metodo = $_SERVER[ 'REQUEST_METHOD' ];
$url = $_SERVER[ 'REQUEST_URI' ];

try {
    $pdo = new PDO(
        'mysql:dbname=pcw;host=localhost;charset=utf8',
        'root', // usuário
        '', // senha
        [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ]
    );
} catch ( Exception $e ) {
    http_response_code( 500 );
    die( $e->getMessage() );
}

if ( $metodo == 'GET' && $url == '/contatos' ) {
    header( 'Content-Type: application/json' );
    // echo '
    // [
    //   { "id": 1, "nome": "Ana",   "telefone": "22334455"  },
    //   { "id": 2, "nome": "Bia",   "telefone": "988887777" },
    //   { "id": 3, "nome": "Júlia", "telefone": "977778888" }
    // ]';
    $ps = $pdo->prepare(
        'SELECT id, nome, telefone FROM contato'
    );
    $ps->setFetchMode( PDO::FETCH_ASSOC );
    $ps->execute();
    echo json_encode( $ps->fetchAll() );

} else if ( $metodo == 'POST' && $url == '/contatos' ) {

    $contato = (array) json_decode(
        file_get_contents( 'php://input' )
    );

    $ps = $pdo->prepare(
      'INSERT INTO contato ( nome, telefone )
       VALUES ( :nome, :telefone )'
    );
    $ps->execute( $contato );

    http_response_code( 201 );
    echo 'Salvo com sucesso.';
} else if ( $metodo != 'OPTIONS' ) {
    http_response_code( 404 );
}


?>