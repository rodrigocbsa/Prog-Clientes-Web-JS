fetch( 'telefones.json' )
    .then( function( response ) {
        if ( response.status >= 400 ) {
            throw new Error( 'código ' + response.status );
        }
        return response.json();
    } )
    .then( function( telefones ) {
        desenharTelefones( telefones );
    } )
    .catch( function( erro ) {
        alert( 'Erro ao consultar telefones: ' + erro.message );
    } )
    .finally( function() {
        console.log( 'Telefones consultados.' );
    } );

function desenharTelefones( telefones ) {
    document.querySelector( 'ul' ).innerHTML =
        telefones.map(
            tel => `<li>(${tel.ddd}) ${tel.numero}</li>`
        ).join( '\n' );
}