fetch( 'telefones.json' )
    .then( function( response ) {
        if ( response.status >= 400 ) {
            throw new Error( 'Erro ao consultar telefones: '
                + response.status );
        }
        response.json()
            .then( function( telefones ) {
                desenharTelefones( telefones );
            } )
            .catch( function( erro ) {
                alert( erro.message );
            } );
    } )
    .catch( function( erro ) {
        alert( erro.message );
    } );

function desenharTelefones( telefones ) {
    document.querySelector( 'ul' ).innerHTML =
        telefones.map(
            tel => `<li>(${tel.ddd}) ${tel.numero}</li>`
        ).join( '\n' );
}